package com.example.cs360project;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import androidx.gridlayout.widget.GridLayout;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class DataActivity extends AppCompatActivity {

    private EditText dateEditText, weightEditText;
    private Button addButton, homeButton2, accountButton2;
    private GridLayout dataGrid;
    private SQLiteDatabase database;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        // Retrieve user ID from intent
        userId = getIntent().getIntExtra("userId", -1); // Default to -1 if not found

        // Initialize Views from activity_data.xml
        dateEditText = findViewById(R.id.dateInput);
        weightEditText = findViewById(R.id.weightInput);
        addButton = findViewById(R.id.inputButton);
        dataGrid = findViewById(R.id.dataGrid);
        homeButton2 = findViewById(R.id.homeButton2);
        accountButton2 = findViewById(R.id.accountButton2);

        homeButton2.setOnClickListener(v -> {
            Intent intent = new Intent(DataActivity.this, MainActivity.class);
            startActivity(intent);
        });

        accountButton2.setOnClickListener(v -> {
            Intent intent = new Intent(DataActivity.this, AccountActivity.class);
            startActivity(intent);
        });

        // Initialize Database
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        database = dbHelper.getWritableDatabase();

        // Display existing data
        displayData();

        // Handle Add Data
        addButton.setOnClickListener(v -> addDataToGrid());
    }

    private void addDataToGrid() {
        String date = dateEditText.getText().toString();
        String weight = weightEditText.getText().toString();

        if (!date.isEmpty() && !weight.isEmpty()) {
            ContentValues values = new ContentValues();
            values.put("userId", userId); // Associate data with the logged-in user
            values.put("date", date);
            values.put("weight", weight);

            long id = database.insert("data", null, values);

            if (id != -1) {
                Toast.makeText(this, "Data Added", Toast.LENGTH_SHORT).show();
                dateEditText.setText("");
                weightEditText.setText("");
                displayData(); // Refresh data display
            } else {
                Toast.makeText(this, "Failed to add data", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Please fill out both fields", Toast.LENGTH_SHORT).show();
        }
    }

    private void displayData() {
        // Clear previous data in the GridLayout
        dataGrid.removeAllViews();

        // Add headers
        addHeaderRow();

        // Query the database to get all data for the current user
        Cursor cursor = database.query("data", null, "userId = ?", new String[]{String.valueOf(userId)}, null, null, null);

        // Check if there are results
        if (cursor.moveToFirst()) {
            do {
                String id = cursor.getString(cursor.getColumnIndexOrThrow("id"));
                String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));
                String weight = cursor.getString(cursor.getColumnIndexOrThrow("weight"));

                // Create a new row for each data entry
                addDataRow(id, date, weight);

            } while (cursor.moveToNext());
        } else {
            // Show a message if no data is found
            Toast.makeText(this, "No data available", Toast.LENGTH_SHORT).show();
        }
        cursor.close();
    }

    private void addHeaderRow() {
        // Create header TextViews
        TextView emptyHeader = new TextView(this);
        emptyHeader.setLayoutParams(new GridLayout.LayoutParams());
        emptyHeader.setText(""); // Empty for alignment

        TextView dateHeader = new TextView(this);
        dateHeader.setLayoutParams(new GridLayout.LayoutParams());
        dateHeader.setText("Date");
        dateHeader.setPadding(8, 8, 8, 8);

        TextView weightHeader = new TextView(this);
        weightHeader.setLayoutParams(new GridLayout.LayoutParams());
        weightHeader.setText("Weight");
        weightHeader.setPadding(8, 8, 8, 8);

        dataGrid.addView(emptyHeader);
        dataGrid.addView(dateHeader);
        dataGrid.addView(weightHeader);
    }

    private void addDataRow(String id, String date, String weight) {
        // Create a delete button
        Button deleteButton = new Button(this);
        deleteButton.setText("Delete");
        deleteButton.setOnClickListener(v -> deleteData(id));

        // Create TextViews for each data entry
        TextView dateTextView = new TextView(this);
        dateTextView.setText(date);
        dateTextView.setPadding(8, 8, 8, 8);

        TextView weightTextView = new TextView(this);
        weightTextView.setText(weight);
        weightTextView.setPadding(8, 8, 8, 8);

        // Add views to GridLayout
        dataGrid.addView(deleteButton);
        dataGrid.addView(dateTextView);
        dataGrid.addView(weightTextView);
    }

    private void deleteData(String id) {
        // Delete the data from the database
        int rowsDeleted = database.delete("data", "id = ?", new String[]{id});

        if (rowsDeleted > 0) {
            Toast.makeText(this, "Data Deleted", Toast.LENGTH_SHORT).show();
            displayData(); // Refresh the GridLayout
        } else {
            Toast.makeText(this, "Failed to delete data", Toast.LENGTH_SHORT).show();
        }
    }
}