package com.example.cs360project;

import android.content.Intent;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText usernameEditText, passwordEditText;
    private Button loginButton, createAccountButton, dataButton, settingsButton;
    private SQLiteDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);  // Use activity_login.xml

        // Initialize Views from activity_login.xml
        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createButton);
        dataButton = findViewById(R.id.dataButton);
        settingsButton = findViewById(R.id.accountButton);

        dataButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, DataActivity.class);
            startActivity(intent);
        });

        settingsButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AccountActivity.class);
            startActivity(intent);
        });

        // Initialize Database
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        database = dbHelper.getWritableDatabase();

        // Handle Login
        loginButton.setOnClickListener(v -> handleLogin());

        // Handle Account Creation
        createAccountButton.setOnClickListener(v -> handleCreateAccount());
    }

    private void handleLogin() {
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        Cursor cursor = null;
        try {
            cursor = database.rawQuery("SELECT * FROM users WHERE username=? AND password=?",
                    new String[]{username, password});

            if (cursor != null && cursor.moveToFirst()) {
                // Successful login, retrieve user ID
                int userId = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();

                // Start DataActivity
                Intent intent = new Intent(MainActivity.this, DataActivity.class);
                intent.putExtra("userId", userId);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
            }
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    private void handleCreateAccount() {
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);

        long id = database.insert("users", null, values);

        if (id != -1) {
            Toast.makeText(this, "Account Created", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Failed to create account", Toast.LENGTH_SHORT).show();
        }
    }
}
