package com.example.cs360project;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class AccountActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1;
    private Switch smsPermissionSwitch;
    private Button homeButton3, dataButton3;

    // SharedPreferences keys
    private static final String PREFS_NAME = "MyPrefs";
    private static final String SMS_PERMISSION_KEY = "sms_permission";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);  // Use activity_account.xml
        homeButton3 = findViewById(R.id.homeButton3);
        dataButton3 = findViewById(R.id.dataButton3);

        homeButton3.setOnClickListener(v -> {
            Intent intent = new Intent(AccountActivity.this, MainActivity.class);
            startActivity(intent);
        });

        dataButton3.setOnClickListener(v -> {
            Intent intent = new Intent(AccountActivity.this, DataActivity.class);
            startActivity(intent);
        });

        // Initialize Views from activity_account.xml
        smsPermissionSwitch = findViewById(R.id.smsSwitch);

        // Retrieve and set the switch state from SharedPreferences
        setSwitchState();

        // Handle SMS Permissions
        smsPermissionSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> handleSMSPermission(isChecked));
    }

    private void setSwitchState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean isSmsPermissionGranted = prefs.getBoolean(SMS_PERMISSION_KEY, false);

        // Check if SMS permission is granted and set switch accordingly
        smsPermissionSwitch.setChecked(isSmsPermissionGranted);
    }

    private void handleSMSPermission(boolean isChecked) {
        if (isChecked) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
            } else {
                sendTestSMS();
            }
        } else {
            // Optionally handle the case where the user unchecks the switch
            Toast.makeText(this, "SMS Permission Disabled", Toast.LENGTH_SHORT).show();
            saveSwitchState(false); // Save the switch state
        }
    }

    private void sendTestSMS() {
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage("5554", null, "Test SMS sent", null, null);
        Toast.makeText(this, "Test SMS Sent", Toast.LENGTH_SHORT).show();
        saveSwitchState(true); // Save the switch state
    }

    private void saveSwitchState(boolean isGranted) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean(SMS_PERMISSION_KEY, isGranted);
        editor.apply();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendTestSMS();
                saveSwitchState(true); // Save the switch state
            } else {
                smsPermissionSwitch.setChecked(false); // Set switch off if permission denied
                saveSwitchState(false); // Save the switch state
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}